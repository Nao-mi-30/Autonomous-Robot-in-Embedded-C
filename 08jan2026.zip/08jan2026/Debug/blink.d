# FIXED

blink.obj: ../blink.c
blink.obj: C:/ti/ccs1230/ccs/ccs_base/msp430/include/msp430.h
blink.obj: C:/ti/ccs1230/ccs/ccs_base/msp430/include/msp430g2553.h
blink.obj: C:/ti/ccs1230/ccs/ccs_base/msp430/include/in430.h
blink.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h
blink.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h
blink.obj: ../ADC.h
blink.obj: ../Afficheur.h

../blink.c:

C:/ti/ccs1230/ccs/ccs_base/msp430/include/msp430.h:

C:/ti/ccs1230/ccs/ccs_base/msp430/include/msp430g2553.h:

C:/ti/ccs1230/ccs/ccs_base/msp430/include/in430.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h:

../ADC.h:

../Afficheur.h:

