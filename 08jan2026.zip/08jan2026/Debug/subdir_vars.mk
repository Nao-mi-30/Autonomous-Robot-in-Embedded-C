################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
../lnk_msp430g2553.cmd 

C_SRCS += \
../ADC.c \
../Afficheur.c \
../blink.c 

C_DEPS += \
./ADC.d \
./Afficheur.d \
./blink.d 

OBJS += \
./ADC.obj \
./Afficheur.obj \
./blink.obj 

OBJS__QUOTED += \
"ADC.obj" \
"Afficheur.obj" \
"blink.obj" 

C_DEPS__QUOTED += \
"ADC.d" \
"Afficheur.d" \
"blink.d" 

C_SRCS__QUOTED += \
"../ADC.c" \
"../Afficheur.c" \
"../blink.c" 


