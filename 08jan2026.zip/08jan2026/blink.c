#include <msp430.h>
#include "ADC.h"
#include "Afficheur.h"


/**
* D�finition des variables
*/
#define seuil_Obstacle 500  // seuil detection d'obstacle
#define seuil_Ligne 800     // seuil suivi de ligne

volatile unsigned int bout=0;         // gestion du bouton
volatile unsigned int i;
unsigned int vitesse=4;     // vitesse du robot
volatile unsigned char voie1=6;
volatile unsigned char voie2=1;
unsigned int valeur1,valeur2;




/**
*Nom: Obstacle_init
*Initialisation de l'ADC
*Activation de l'entr�e analogique A7
*/
void Obstacle_init(void)
{

    ADC10AE0 |= BIT7; // activer entr�e analogique A7 (P1.7)
    ADC_init();
}

/**
*Nom: Obstacle_isDetected
*D�tection d'obstacle
*Renvoi 1 si l'obstacle est detect� et 0 sinon
*/
unsigned char Obstacle_isDetected(void)
{
    ADC_Demarrer_conversion(7);      // canal A4

    int adc = ADC_Lire_resultat();   // 0..1023

    return (adc > seuil_Obstacle) ? 1 : 0;
}


/**
*Nom: config_direction
*/
void config_direction(){

//Moteur A
    P2SEL &= ~(BIT0 );
    P2SEL2 &= ~(BIT0 );
    P2DIR &= ~(BIT0); // mettre en entr�e
    P2SEL &= ~(BIT1);
    P2SEL2 &= ~( BIT1);
    P2DIR |= ( BIT1); // mettre en sortie

//Moteur B
    P2SEL &= ~(BIT3);
    P2SEL2 &= ~(BIT3);
    P2DIR &= ~(BIT3); // mettre en entr�e
    P2SEL &= ~(BIT5);
    P2SEL2 &= ~( BIT5);
    P2DIR |= ( BIT5); // mettre en sortie
}

/**
*Nom: avancer
*
*/
void avancer(){

    P2OUT |= (BIT1 | BIT5);

//Moteur A
     P2OUT  &= ~(BIT1); // met la roue A � 0

//Moteur B
     P2OUT |= (BIT5); // met la roue B � 1

// activation des PMW
     TA1CCR1 = vitesse;
     TA1CCR2 = vitesse;
}


/**
*Nom: reculer
*/void reculer(){

    P2OUT &= ~ (BIT1 | BIT5);

    // activation des PMW
    TA1CCR1 = vitesse;
    TA1CCR2 = vitesse;
}


/**
*Nom: tourner � gauche
*/
void tourner_gauche(){

    P2OUT &= ~(BIT1); // met la roue A � 0
    P2OUT |= (BIT5); // met la roue B � 1
    P2OUT |= (BIT5); // met la roue B � 1
    TA1CCR1 = 0;   // roue A � l�arret
    TA1CCR2 = vitesse;
}

/**
*Nom: tourner_droite
*/
void  tourner_droite(){
    P2OUT |=(BIT1); // met la roue A � 1
    P2OUT &= ~(BIT1); // met la roue A � 1
    P2OUT &= ~(BIT5); // met la roue B � 0--
    TA1CCR2 = 0;   // roue B � l�arret
    TA1CCR1 = vitesse;
}


/**
*Nom: arret
*/
void arret(){
    TA1CCR2 = 0;
    TA1CCR1 = 0;
}


/**
*Nom: timer
*/
void timer(){

    BCSCTL1= CALBC1_1MHZ; //frequence d�horloge 1MHz

    DCOCTL= CALDCO_1MHZ; //

    TA1CTL = TASSEL_2 | MC_1 ; // source SMCLK pour TimerA , mode comptage Up

    //Roue B

    TA1CCTL2 |= OUTMOD_7; // activation mode de sortie n�7

    TA1CCR0 = 4; // determine la periode du signal

    TA1CCR2 = 0; // determine le rapport cyclique du signal

    P2DIR |= BIT4; // P2.4 en sortie

    P2SEL |= BIT4; // selection fonction TA1.2

    P2SEL2 &= ~BIT4; // selection fonction TA1.2


    //Roue A

    TA1CCTL1 |= OUTMOD_7; // activation mode de sortie n�7

    TA1CCR0 = 4; // determine la periode du signal

    TA1CCR1 = 0; // determine le rapport cyclique du signal

     P2DIR |= BIT2; // P2.2 en sortie

     P2SEL |= BIT2; // selection fonction TA1.1

     P2SEL2 &= ~BIT2; // selection fonction TA1.1

}


/**
*Nom: timer
*/
void activation_bouton_demarrer(){
    P1DIR &= ~(BIT3);
    P1REN |= BIT3; // activation r�sistance interne
    P1OUT |= BIT3; // mode pull-up
    P1IE |= BIT3; // initialisation de l'interruption
    P1IES |= BIT3; // interruption sur front descendant

    // donc appui car bouton connecte a la masse
    P1IFG &= ~(BIT3); // RAZ flag d�interruption
}


/**
*Nom: deplacement_suivi_de_lignes
*Assure le d�placement du robot suivant les lignes
*/
void deplacement_suivi_de_lignes()
{

    ADC_Demarrer_conversion(voie1);
    valeur1=ADC_Lire_resultat ();
    //Aff_valeur(convert_Hex_Dec(valeur1));

    ADC_Demarrer_conversion(voie2);
    valeur2=ADC_Lire_resultat ();

  if(valeur1>seuil_Ligne && valeur2>seuil_Ligne)
      avancer();

  //P1.6 est a droite et P1.1 est a gauche

  if(valeur1>seuil_Ligne && valeur2<seuil_Ligne)
      tourner_gauche();

  if(valeur1<seuil_Ligne && valeur2>seuil_Ligne)
      tourner_droite();
}


/**
*Nom: Main
*/
void main(void){

    WDTCTL = WDTPW | WDTHOLD;       // stop watchdog timer

    volatile unsigned int i;        // volatile to prevent optimization


    config_direction();
    timer();
    Obstacle_init();
    activation_bouton_demarrer();

    __enable_interrupt(); // activation g�n�rale des interruptions

    ADC_init();
    //Aff_Init();

    while(1){
        if(bout)
        {


            if( Obstacle_isDetected() == 1)
                arret();
            else
                deplacement_suivi_de_lignes();
        }
    }
}


/**
*Interruption sur le bouton S2
*/
#pragma vector= PORT1_VECTOR
__interrupt void detect_bouton(void)
{
   if(P1IFG & BIT3)
   {
       bout^=1;
       P1IFG &=~ BIT3;
       __delay_cycles(20000);
   }
}

/**
 *Interruption pour le timer
*/
#pragma vector= TIMER1_A1_VECTOR //voir diaporama seance precedente
__interrupt void ma_fnc_timer(void)
{
switch(__even_in_range(TA1IV,10)){
     case 10:
         break;
     default:
         break;
}
}

